import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# Load and clean data
df = pd.read_csv('adult.csv')
df.replace('?', np.nan, inplace=True)
df.dropna(inplace=True)

# Encode categorical columns
label_encoders = {}
for col in df.select_dtypes(include='object').columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

protected_attr = 'sex'  # 0 = Female, 1 = Male
target = 'income'

X = df.drop(columns=[target])
y = df[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.3, random_state=42)

# Baseline model
clf = LogisticRegression(max_iter=1000)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)
protected_test = X_test[protected_attr].values

# Fairness metrics functions
def statistical_parity_difference(y_pred, protected_attr_vals):
    return np.mean(y_pred[protected_attr_vals == 0]) - np.mean(y_pred[protected_attr_vals == 1])

def disparate_impact(y_pred, protected_attr_vals):
    return np.mean(y_pred[protected_attr_vals == 0]) / np.mean(y_pred[protected_attr_vals == 1])

def equal_opportunity_difference(y_true, y_pred, protected_attr_vals):
    priv = (protected_attr_vals == 1)
    unpriv = (protected_attr_vals == 0)
    tpr_priv = np.sum((y_pred == 1) & (y_true == 1) & priv) / np.sum((y_true == 1) & priv)
    tpr_unpriv = np.sum((y_pred == 1) & (y_true == 1) & unpriv) / np.sum((y_true == 1) & unpriv)
    return tpr_unpriv - tpr_priv

# Evaluate baseline
baseline_metrics = {
    'accuracy': accuracy_score(y_test, y_pred),
    'statistical_parity': statistical_parity_difference(y_pred, protected_test),
    'disparate_impact': disparate_impact(y_pred, protected_test),
    'equal_opportunity': equal_opportunity_difference(y_test.values, y_pred, protected_test)
}

print("\U0001F50D Baseline Fairness Metrics:")
print(baseline_metrics)

# Mitigation 1: Reweighing
group_counts = df.groupby([protected_attr, target]).size()
weights = {}
for (sex_val, income_val), count in group_counts.items():
    weights[(sex_val, income_val)] = 1.0 / count

sample_weights = X_train.apply(lambda row: weights[(row[protected_attr], y_train.loc[row.name])], axis=1)
clf_reweighted = LogisticRegression(max_iter=1000)
clf_reweighted.fit(X_train, y_train, sample_weight=sample_weights)
y_pred_rw = clf_reweighted.predict(X_test)

rw_metrics = {
    'accuracy': accuracy_score(y_test, y_pred_rw),
    'statistical_parity': statistical_parity_difference(y_pred_rw, protected_test),
    'disparate_impact': disparate_impact(y_pred_rw, protected_test),
    'equal_opportunity': equal_opportunity_difference(y_test.values, y_pred_rw, protected_test)
}

print("\n\U0001F6E0️ After Reweighing:")
print(rw_metrics)

# Mitigation 2: Threshold Adjustment
y_probs = clf_reweighted.predict_proba(X_test)[:, 1]
male_idx = X_test[protected_attr] == 1
female_idx = X_test[protected_attr] == 0

threshold_male = 0.35
threshold_female = 0.25

y_pred_adj = np.zeros_like(y_test)
y_pred_adj[male_idx] = (y_probs[male_idx] > threshold_male).astype(int)
y_pred_adj[female_idx] = (y_probs[female_idx] > threshold_female).astype(int)

adj_metrics = {
    'accuracy': accuracy_score(y_test, y_pred_adj),
    'statistical_parity': statistical_parity_difference(y_pred_adj, protected_test),
    'disparate_impact': disparate_impact(y_pred_adj, protected_test),
    'equal_opportunity': equal_opportunity_difference(y_test.values, y_pred_adj, protected_test)
}

print("\n\U0001F3AF After Threshold Adjustment:")
print(adj_metrics)

# Visualization 1: Income Distribution by Gender
def plot_income_by_gender(df, label_encoders):
    decoded_df = df.copy()
    decoded_df['sex'] = label_encoders['sex'].inverse_transform(df['sex'])
    decoded_df['income'] = label_encoders['income'].inverse_transform(df['income'])
    sns.set(style="whitegrid")
    plt.figure(figsize=(8, 5))
    sns.countplot(data=decoded_df, x='sex', hue='income')
    plt.title('Income Distribution by Gender')
    plt.ylabel('Count')
    plt.xlabel('Gender')
    plt.legend(title='Income')
    plt.tight_layout()
    plt.show()

# Visualization 2: Correlation Matrix
def plot_correlation_matrix(df):
    plt.figure(figsize=(12, 10))
    corr = df.corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm', square=True)
    plt.title('Feature Correlation Matrix')
    plt.tight_layout()
    plt.show()

# Visualization 3: Fairness Metrics Across Models
def plot_fairness_metrics(metrics_dict):
    categories = list(metrics_dict['baseline'].keys())
    models = list(metrics_dict.keys())
    values = {metric: [metrics_dict[model][metric] for model in models] for metric in categories}
    x = np.arange(len(models))
    width = 0.2
    fig, ax = plt.subplots(figsize=(10, 6))
    for i, metric in enumerate(categories):
        ax.bar(x + i * width, values[metric], width, label=metric)
    ax.set_xticks(x + width)
    ax.set_xticklabels(models)
    ax.set_ylabel("Metric Value")
    ax.set_title("Fairness Metrics Comparison Across Models")
    ax.legend()
    plt.tight_layout()
    plt.show()

# Plot all visualizations
plot_income_by_gender(df, label_encoders)
plot_correlation_matrix(df)
metrics_dict = {'baseline': baseline_metrics, 'reweighed': rw_metrics, 'adjusted': adj_metrics}
plot_fairness_metrics(metrics_dict)
